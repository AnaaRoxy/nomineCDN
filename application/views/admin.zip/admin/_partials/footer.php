<!-- footer content -->
<footer>
  <div class="pull-right">
    &copy Copyright By <a href="//nomine.id">Nomine</a>
  </div>
  <div class="clearfix"></div>
</footer>
<!-- /footer content -->