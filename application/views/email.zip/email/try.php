<!DOCTYPE html>

<html>

<head>

  <meta charset="utf-8" />

  <title>Anil Labs - Codeigniter mail templates</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

</head>

<body>

<div>

  <div style="font-size: 26px;font-weight: 700;letter-spacing: -0.02em;line-height: 32px;color: #41637e;font-family: Roboto, sans-serif;text-align: center" align="center" id="emb-email-header"><img style="border: 0;-ms-interpolation-mode: bicubic;display: block;Margin-left: auto;Margin-right: auto;max-width: 152px" src="https://www.nomine.id/images/favicon.ico" alt="" width="152" height="152"></div>
<br/>

<p style="Margin-top: 0;color: #565656;font-family: Roboto,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Terimakasih  <?php echo $nama;?> Sudah Mendaftar Menjadi Mitra <?php echo $level ?> Nomine</p>

<p style="Margin-top: 0;color: #565656;font-family: Roboto,serif;font-size: 16px;line-height: 25px;Margin-bottom: 25px">Silahkan Verifikasi Kemitraan Kamu ke <a href="http://bit.ly/AdmNomine1">Admin kami</a> </p>

</div>

</body>

</html>